riot.mount('*');


let cNavName = 'azkar';
// let activeEl = document.querySelector('nav.nav a.active');
let content = document.getElementById('content');
let contentW = content.offsetWidth;
let subcontentW = contentW * 4;
let subcontent = document.querySelector('#subcontent');
let app = document.querySelector('#app');
let is_desktop = false;
let myElement = document.getElementById('subcontent');
let myElement2 = document.getElementById('app');
let scroller = document.querySelector('#scroller')
let activeEl


function resetActive() {
    let navParent = document.querySelector('nav.nav');
    let elChildren = navParent.childNodes;
    elChildren.forEach((val, index) => {
        elChildren[index].classList.remove('active');
    });
}

function navFromTo(toNav) {
    activeEl = document.querySelector('nav.nav a.active');
    activeEl.addEventListener('click', function (e) {
        // console.log('clcik');
        if (!is_desktop) {
            scroller.scrollTop = 0;
        } else {
            if (is_desktop) {
                // console.log(document.querySelector('#page-top'))
                // documentElement.scrollTop = 0;
                window.scrollTo(0, 0);
            }
        }
    });

    let navEl = ['azkar', 'duaa', 'roqya', 'favorite'];
    let fNav = document.querySelector("a[href='/" + cNavName + "']");
    let fNavPos = navEl.indexOf(fNav.attributes['data-name'].value)
    let tNav = document.querySelector("a[href='/" + toNav + "']");
    let tNavPos = navEl.indexOf(tNav.attributes['data-name'].value)
    let cTranslateX = get_trans(subcontent.style.transform);
    // console.log('fNavPos:', fNavPos)
    // console.log('tNavPos:', tNavPos)

    //do Translation sliding
    if (fNavPos < tNavPos) {
        // console.log('fNavPos < tNavPos')
        let noMove = (tNavPos - fNavPos) * contentW;
        // console.log('c translateX:', cTranslateX)
        // console.log('new translateX:', noMove)
        subcontent.style.transform = 'translateX(' + (noMove + cTranslateX) + 'px)';
        // scroller.scrollTop = 0;

    } else {
        if (fNavPos > tNavPos) {
            // console.log('fNavPos > tNavPos')
            let noMove = (tNavPos - fNavPos) * contentW;
            // console.log('c translateX:', cTranslateX)
            // console.log('new translateX:', noMove)
            subcontent.style.transform = 'translateX(' + (noMove + cTranslateX) + 'px)';
        }
    }


    if (is_desktop) {
        window.scrollTo(0, 0);
    } else {
        if (cNavName !== 'duaa') {
            scroller.scrollTop = 0;
        }
    }

// console.log(subcontent.height)
    cNavName = toNav;
    resetSubHight();

}


route.base('/');
route.start(true);

route('/azkar', function () {
    // console.log(document.querySelector('nav.nav .active').attributes['data-name'].value);
    // riot.mount('.contentInternal', 'azkar-sec');
    navFromTo('azkar')
});
route('/duaa', function () {
    // riot.mount('.contentInternal', 'duaa-sec');
    navFromTo('duaa')
});
route('/roqya', function () {
    // riot.mount('.contentInternal', 'roqya-sec');
    navFromTo('roqya')
});
route('/favorite', function () {
    // riot.mount('.contentInternal', 'favorite-sec');
    navFromTo('favorite')
});

route('favorite');
route('azkar');

//on change oriantation refresh screen
window.addEventListener("orientationchange", function () {
    window.location.reload();

}, false);

/*on resize refresh screen
issue: reload every time on search*/
window.addEventListener("resize", function () {
    let isIOS = /iPad|iPhone|iPod/.test(navigator.platform) ||
        (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

    if (app.classList.contains('desktop') && !isIOS) {
        window.location.reload();
    }

}, false);

// for history
window.addEventListener('popstate', function (e) {
    // console.log('history:',history)
    let cPath = window.location.pathname;
    if (cPath !== '/about') {
        document.querySelector('#info').classList.add('closeAnim')
    }
    if (document.querySelector('#search_sub').classList.contains('closeAnim')) {
        document.querySelector('#search_results').classList.add('closeAnim')
    }
    let navEl = ['/azkar', '/duaa', '/roqya', '/favorite'];
    if (navEl.indexOf(cPath) === -1) {
        cPath = '/azkar'
    }

    document.querySelector('#search_sub').classList.add('closeAnim');
    // document.querySelector('#search_results').setAttribute('hidden','')
    resetActive();
    document.querySelector("a[href='" + cPath + "']").classList.add('active');

});


var lastScrollTop = 0, delta = 5;

function checkScroll(scrollPosition) {
    let cScrollW = content.scrollWidth;

    scroller.scrollLeft = contentW * 3;
    // console.log('current scroll left:', content.scrollLeft);
    // console.log('current scroll width:', content.scrollWidth)
    // var info = document.getElementById("info");
    var nowScrollTop = scrollPosition.scrollTop;
    // console.log('scroll pos:', scrollPosition.scrollTop);
    // console.log('scroll left:',scrollPosition.scrollLeft)
    // info.innerHTML = "Vertical: " + scrollPosition.scrollTop + "px";

    if (Math.abs(lastScrollTop - nowScrollTop) >= delta) {
        // scroll down
        if (nowScrollTop > lastScrollTop) {
            // console.log('down');
            // if (app.classList.contains('desktop')) {
            //     console.log(app.classList.contains('desktop'))
            // }
            document.querySelector('#app').classList.add('headsmall');


        } else {
            // scroll up
            // console.log('up');
            document.querySelector('#app').classList.remove('headsmall');
            // console.log('up');

            // document.querySelector('#azkar .catParent').style.top = scrollPosition.scrollTop + 'px';
            // document.querySelector('#roqya .catParent').style.top = scrollPosition.scrollTop + 'px';
        }
        lastScrollTop = nowScrollTop;
    }

}

//remove التشكيل
function replaceAccents() {
    var elem;
    var text = (elem = document.getElementById("txt")).value;
    elem.value = text.replace(new RegExp(String.fromCharCode(1617, 124, 1614, 124, 1611, 124, 1615, 124, 1612, 124, 1616, 124, 1613, 124, 1618), "g"), "");
}


function setWidths() {

    // console.log(contentW + 'px');
    subcontent.style.width = subcontentW + "px";
    // console.log('content width', contentW);
    let _allEle = subcontent.childNodes;
    _allEle.forEach((value, index) => {
        _allEle[index].style.width = contentW + 'px';
    });
    subcontent.style.transform = "translateX(0px)";

}

function get_trans(trans) {
    let str = trans.substr(11);
    let len = str.length - 3;
    // console.log('len:',len)
    let newVal = str.substr(0, len)
    // console.log('newVal:',newVal)
    return parseInt(newVal);
}

function switchSlide(newTrans) {

    resetActive()

    switch (newTrans) {
        case 0:
            document.querySelector("a[href='" + '/azkar' + "']").classList.add('active');
            cNavName = 'azkar';
            route('azkar');
            break;
        case contentW:
            document.querySelector("a[href='" + '/duaa' + "']").classList.add('active');
            cNavName = 'duaa';
            route('duaa');
            break;
        case contentW * 2:
            document.querySelector("a[href='" + '/roqya' + "']").classList.add('active');
            cNavName = 'roqya';
            route('roqya');
            break;
        case contentW * 3:
            document.querySelector("a[href='" + '/favorite' + "']").classList.add('active');
            cNavName = 'favorite';
            route('favorite');
            break;
    }
    return 'translateX(' + newTrans + 'px)';

}

function slide(cTrans, sPos) {
    // console.log('cTrans:', cTrans);
    let _cTrans = get_trans(cTrans);
    let _newTrans;
    // console.log('_cTrans:', _cTrans);


    if (sPos === 'r' || sPos === 'l') {
        if (sPos === 'r' && _cTrans !== (subcontentW - contentW)) {
            _newTrans = _cTrans + contentW;
            // console.log('new Trans:', _newTrans);
            return switchSlide(_newTrans);
        }
        if (sPos === 'l' && _cTrans !== 0) {
            _newTrans = _cTrans - contentW;
            // console.log('new Trans:', _newTrans);
            return switchSlide(_newTrans);
        }
    }

    // _newTrans = _cTrans;

    // console.log('from slid:', 'translateX(' + _newTrans + 'px)');
}


//allow select text
delete Hammer.defaults.cssProps.userSelect;
var hammertime = new Hammer(myElement);
hammertime.on('swipeleft', function (ev) {
    // console.log('swipe left: ', ev);
    subcontent.style.transform = slide(subcontent.style.transform, 'l');
    scroller.scrollTop = 0;
    scroller.scrollLeft = contentW * 3;
});
hammertime.on('swiperight', function (ev) {

    subcontent.style.transform = slide(subcontent.style.transform, 'r');
    scroller.scrollTop = 0;
    scroller.scrollLeft = contentW * 3;

    //     console.log(scroller);

});


// var mySwipeIt = new SwipeIt('#subcontent');
// mySwipeIt
//     .on('swipeLeft', function (e) {
//         //your handler here
//         // alert('mySwipeIt is on swipeLeft!');
//         subcontent.style.transform = slide(subcontent.style.transform, 'l');
//         scroller.scrollTop = 0;
//         scroller.scrollLeft = contentW * 3;
//     })
//     .on('swipeRight', function (e) {
//         //your handler here
//         // alert('mySwipeIt is on swipeRight!');
//         subcontent.style.transform = slide(subcontent.style.transform, 'r');
//         scroller.scrollTop = 0;
//         scroller.scrollLeft = contentW * 3;
//     });

// hammertime.on('press', function (ev) {
//
//
//     console.log('test:', ev);
//     // console.log('test2:',ev.target.innerText);
//     console.log('test2:', ev.target.childNodes[0].data);
//     // selectElementText(ev.target);
//     // selectElementText(ev.target.childNodes[0]);
//     // selectElementText(ev.target.textContent);
//
//     // if (ev.target.className == 'select') {
//     //     console.log('ok');
//     //     selectElementText(ev.target) // select the element's text we wish to read
//     //     var copysuccess = copySelectionText()
//     //     if (copysuccess) {
//     //         // showtooltip(e)
//     //         console.log('co:', copysuccess);
//     //     } else {
//     //         console.log('faild:');
//     //     }
//     // }
//
//     // document.execCommand("Copy");
//     // console.log('from clipoard: ', getSelectionText());
//
//
//
//
// });


function resetSubHight() {
    // console.log('from main reset heieght ')
    let _activeEl = document.querySelector('nav.nav a.active').getAttribute('data-name');
    subcontent.style.height = document.getElementById(_activeEl).offsetHeight + 200 + 'px'
    // if (is_desktop) {
    //     // console.log(_activeEl, document.getElementById(_activeEl).offsetHeight)
    // }
}

function checkDevice() {
    var parser = new UAParser();
    var result = parser.getResult();
    var _device = result.device.type;
    var _browser = result.browser.name;
    var _os = result.os.name;
    var _app = document.getElementById('app')
    // console.log('os:',_os);
    // console.log('result:', result);
    let isIOS = /iPad|iPhone|iPod/.test(navigator.platform) ||
        (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

    if (_device !== 'mobile' && _device !== 'tablet') {
    // if (_device !== 'mobile' && _device !== 'tablet' && !isIOS) {
        _app.classList.add('desktop');
        is_desktop = true;
        // if (_app.offsetWidth > 1200) {
        // }
        if (_browser === 'Edge') {
            _app.classList.add('edge')
        }
    } else {
        if (_device === 'mobile' || _device === 'tablet') {
            if (_os === 'Android') {
                _app.classList.add('android')
            }
            if (_os === 'iOS' || isIOS) {
                _app.classList.add('ios')
            }
        }
    }
    // is_desktop = app.classList.contains('desktop');
    // console.log('test :',app.classList.contains('desktop'))
    // console.log(result);
}

function loaded() {
    checkDevice();
    setWidths();
    resetSubHight();


}
// import { gsap } from "gsap/dist/gsap";
// var gsap = require("gsap").gsap;
// var gsap = require("../vendor/gsap").gsap;
// var MotionPathPlugin = require("gsap/dist/MotionPathPlugin").MotionPathPlugin;
// var ScrollToPlugin = require("../vendor/ScrollToPlugin").ScrollToPlugin;




riot.tag2('app', '<h1 class="sr-only">ذاكرون - تطبيق ويب للأدعية والأذكار</h1><div id="heading" data-is="heading"></div><div id="content" class="" data-is="contents"></div><div id="search_results" data-is="search_results"></div><div id="search_sub" data-is="search_sub"></div><div id="info" data-is="info"></div>', '', '', function(opts) {
});

riot.tag2('azkar-sec', '<h2 class="sr-only">أذكار</h2><div class="catParent"><div class="category d-flex justify-content-around mt-4 mb-2 mx-4" ref="category"><span class="d-block active" onclick="{getMorning}">أذكار الصباح</span><span class="d-block" onclick="{getEvening}">أذكار المساء</span></div></div><ol class="staple{contentChange}"><virtual each="{azkar}"><li onclick="{selectRowLocal}"><span> {zekr.replace(/[\\n\\r]+/g, ⁗ ⁗)} </span><span class="count"> {this.updateCount(count)} </span><span class="reference"> {this.updateRef(ref,azkarCat)} </span><span class="description"> {desc} </span><div class="meta d-flex justify-content-between align-items-center"><button class="icon-share share d-none" onclick="{sendToShareContent}"><span>شارك</span></button><input type="button" class="counter d-none" data-count="{count}" data-value="0" onclick="{counterClick}" riot-value="{counter}"><a class="fav text-left" title="المفضلة" onclick="{fav}" show="{checkWebStorage}"><span>{favText}</span><span class="{favIcon} icon" aria-hidden="true"></span></a></div></li></virtual></ol>', '', '', function(opts) {
        this.contentChange = ' change1';
        this.favIcon;
        this.azkarCat = 'azkar_s';
        this.counter = "عداد";
        this.favText = 'المفضلة';

        this.favorite.on('border', () => {

            this.favIcon = 'icon-favorite_border'
        });
        this.favorite.on('fill', () => {

            this.favIcon = 'icon-favorite_fill'
        });
        this.favorite.on('update', () => {
            this.update();
        });
        this.selectRowLocal = (e) => {
            this.selectRow(e, this.root.id);
            this.checkWebStorage(e);
        }

        this.sendToShareContent = (e) => {
            this.shareContent(e, this.azkarCat);
        };

        this.setData = () => {

            this.getData(this.azkarCat);
            this.zakroon.one('azkar complete', (res) => {

                this.azkar = res;

                this.update();
                this.resetSubHight(0);

            })
        }
        this.getMorning = (e) => {
            this.azkarCat = 'azkar_s';
            this.removeActive(this.refs.category, e);
            this.contentChange = ' change1';
            this.setData();
        }

        this.getEvening = (e) => {
            this.azkarCat = 'azkar_m';
            this.removeActive(this.refs.category, e);
            this.contentChange = ' change2';
            this.setData();
        }
        this.on('mount', () => {
            this.setData();

        })

});
riot.tag2('contents', '<div id="scroller" class="scroller" onscroll="checkScroll(this)"><div id="subcontent" onload="stopLoading()" class="d-flex"><div id="azkar" class="sec" data-is="azkar-sec"></div><div id="duaa" class="sec" data-is="duaa-sec"></div><div id="roqya" class="sec" data-is="roqya-sec"></div><div id="favorite" class="sec" data-is="favorite-sec"></div></div></div>', '', '', function(opts) {
        this.on('mount', (ev) => {

            this.resetSubHight(0);
        });

        stopLoading = () => {

            this.resetSubHight(0);

        }

});

riot.tag2('duaa-sec', '<h2 class="sr-only">أدعية</h2><ol class="staple"><virtual each="{name, i in azkar}"><li onclick="{selectRow}"> {name} </li></virtual></ol>', '', '', function(opts) {
        this.azkar = new Array;

        this.trigger_open_search_sub = (e) => {
            this.search.trigger('open_search_sub', e)
            route('popup');
        }
        this.selectRow = (e) => {

            this.removeSelect('duaa', e)
            this.trigger_open_search_sub(e);
        }

        this.setData = () => {

            this.zakroon.one('duaa complete', (res, duaa2) => {

                this.azkar = duaa2;

                this.update()
            })
        }

        this.on('mount', () => {

            this.getData('duaa');
            this.setData();

        })

});
riot.tag2('favorite-sec', '<h2 class="sr-only">المفضلة</h2><ol class="staple"><li class="noFav text-center"> المفضلة فارغة! <br><span class="h6"> اضغط على الدعاء لتظهر أيقونة الإضافة </span></li><virtual each="{azkar}"><li onclick="{selectRowLocal}"><span> {zekr.replace(/[\\n\\r]+/g, ⁗ ⁗)} </span><span class="count d-block"> {this.updateCount(count)} </span><span class="reference"> {this.updateRef(reference,category)} </span><span class="description"> {description} </span><div class="meta d-flex justify-content-between align-items-center"><button class="icon-share share d-none" onclick="{sendToShareContent}"><span>شارك</span></button><input type="button" class="counter d-none" data-count="{count}" data-value="0" onclick="{counterClick}" riot-value="{counter}"><a class="fav text-left" title="المفضلة" onclick="{fav}" show="{checkWebStorage}"><span>{favText}</span><span class="{favIcon} icon" aria-hidden="true"></span></a></div></li></virtual></ol>', '', '', function(opts) {
        this.noFav = document.querySelector('#favorite .noFav');

        this.counter = "عداد";
        this.favText = 'المفضلة';

        this.favorite.on('border', () => {

        });
        this.favorite.on('fill', () => {

        });

        this.sendToShareContent = (e) => {
            this.shareContent(e, this.azkarCat);
        };

        this.favorite.on('update', () => {

            setTimeout(this.getFav, 300);

        });

        this.selectRowLocal = (e) => {
            this.selectRow(e, this.root.id);
            this.checkWebStorage(e);
        }
        this.getFav = () => {
            let myFav = localStorage.getItem("myFav");
            let res = [];
            let elIndex;
            if (myFav !== undefined) {
                res = JSON.parse(myFav);

                this.azkar = res;

                if (this.azkar !== null) {
                    if (this.azkar.length !== 0) {
                        this.noFav.style.display = 'none'
                    }
                    else {
                        this.noFav.style.display = 'block'
                    }

                }
                else {
                    this.noFav.style.display = 'block'
                }

            }

            this.update()

        }

        this.on('mount', () => {
            this.noFav = document.querySelector('#favorite .noFav');
            this.getFav();

        })

});
riot.tag2('heading', '<div class="internal"><div class="headtop d-flex justify-content-between align-items-center px-3 py-1"><a class="navbar-brand mr-0" href="https://zakroon.com"><span>ذاكرون</span><span class="ver" dir="ltr" title="الإصدارة بيتا">.43</span></a><div id="search-box" data-is="search-box"></div><div><button class="icon-info_outline info" onclick="{showInfo}"><span class="sr-only">معلومات حول التطبيق</span></button><button title="تغيير الإضاءة" class="setting {icon}" onclick="{setSettingIcon}" if="{showSetting}"><span class="sr-only">الإعدادات</span></button></div></div><div id="navi" data-is="navi"></div></div>', '', '', function(opts) {
        this.icon = this.checkSettingIcon();
        this.showSetting = false;
        this.setting.on('show', () => {
            this.showSetting = true;
            this.update()
        });

        this.setting.on('hide', () => {
            this.showSetting = false;
            this.update()
        });
        this.showInfo = ()=>{
          this.zakroon.trigger('open_info')
        };

        this.on('mount', () => {
            this.isSupportWebStorage(e);

        })

});

riot.tag2('info', '<div class="heading d-flex justify-content-between align-items-center flex-row-reverse"><button class="icon-close closeBtn" onclick="{close_search_sub}"><span class="sr-only">أغلق</span></button><span class="title d-inline-block text-center"> حول تطبيق ذاكرون </span></div><div class="results container"><div class="row align-self-center"><div class="mb-3 col-lg-8 col-md-10 col-sm-12"><h2 class="text-center h3 pb-3"> ذاكرون <br><span class="h4">(zakroon)</span></h2><p class="h5"><b> ذاكرون </b> هو موقع وتطبيق للأذكار والأدعية، يحتوي على أذكار حصن المسلم وأدعية الصباح والمساء والرقية من الكتاب والسنة. </p><p class="h5"> يمكن تنصيبه كتطبيق من خلال المتصفح مباشرة وبدون متجر البرامج، أيضا يمكنه العمل بدون اتصال بشبكة الإنترنت. </p></div></div><div class="row align-self-center"><div class="text-center"><span>للإقتراحات والملاحظات</span><br><span><a class="h6" href="mailto:info@zakroon.com" title="البريد الإلكتروني">info@zakroon.com</a><br><a class="h6 d-inline-block" style="direction: ltr" href="https://twitter.com/zakroon_app" title="حساب تطبيق ذاكرون على تويتر">@zakroon_app</a></span></div></div><div class="row align-self-center"><div class="text-center"><span class="d-block"> المصادر والمراجع </span><span><a class="h6" href="http://www.imadislam.com/hisnulmuslim/">حصن المسلم لسعيد القحطاني</a></span><br><span><a class="h6" href="https://www.islambook.com/">موقع كتاب الإسلام</a></span><br><span><a class="h6" href="https://github.com/osamayy/azkar-db">قاعدة البيانات</a></span></div></div><div class="row align-self-center"><div class="text-center"><span>تطوير</span><br><span><a class="h6" href="https://osamayy.com">أسامة يونس لاستشارات تجربة المستخدم UX</a></span></div></div></div></div>', '', '', function(opts) {
        this.routefrom = '';
        this.close_search_sub2 = () => {
            this.root.hidden = true;
            route(routefrom);

            this.update();
            this.resetSubHight('flex', 'desktop');

        };
        this.close_search_sub = () => {
            this.root.classList.add('closeAnim')
            setTimeout(this.close_search_sub2, 400);
        };

        this.on('mount', () => {
            this.root.hidden = true;

            this.zakroon.on("open_info", () => {
                this.root.hidden = false;
                routefrom = location.pathname.substr(1);

                route('about');
                this.root.classList.remove('closeAnim')
                this.resetSubHight('none', 'desktop');
                this.update()

            })

        })

});

riot.tag2('navi', '<nav class="nav nav-fill" role="navigation" ref="nav"><a class="nav-item nav-link active" onclick="{checkPath}" href="/azkar" data-name="azkar">أذكار</a><a class="nav-item nav-link" onclick="{checkPath}" href="/duaa" data-name="duaa">أدعية</a><a class="nav-item nav-link" onclick="{checkPath}" href="/roqya" data-name="roqya">رقية</a><a class="nav-item nav-link" onclick="{checkPath}" href="/favorite" data-name="favorite">المفضلة</a></nav>', '', '', function(opts) {


        this.checkPath = (e) => {
            _link = e.target.getAttribute('data-name');

            this.removeActive(this.refs.nav, e)

        };

        this.on('*', (ev) => {

            if(ev === 'update'){

                this.navi.trigger('navi update')

            }
        });

});

riot.tag2('roqya-sec', '<h2 class="sr-only">رقية</h2><div class="catParent"><div class="category d-flex justify-content-around mt-4 mb-2 mx-4" ref="category"><span class="d-block active" onclick="{getSunna}">من السنة</span><span class="d-block" onclick="{getQuran}">من القرآن</span></div></div><ol class="staple{contentChange}"><virtual each="{azkar}"><li onclick="{selectRowLocal}"><span> {zekr.replace(/[\\n\\r]+/g, ⁗ ⁗)} </span><span class="count"> {this.updateCount(count)} </span><span class="reference"> {this.updateRef(ref,roqyaCat)} </span><span class="description"> {desc} </span><div class="meta d-flex justify-content-between align-items-center"><button class="icon-share share d-none" onclick="{sendToShareContent}"><span>شارك</span></button><input type="button" class="counter d-none" data-count="{count}" data-value="0" onclick="{counterClick}" riot-value="{counter}"><a class="fav text-left" title="المفضلة" onclick="{fav}" show="{checkWebStorage}"><span>{favText}</span><span class="{favIcon} icon" aria-hidden="true"></span></a></div></li></virtual></ol>', '', '', function(opts) {
        this.counter = "عداد";
        this.favText = 'المفضلة';

        this.contentChange = ' change1';
        this.favIcon;
        this.roqyaCat = "roqya_s";
        this.favorite.on('border', () => {

            this.favIcon = 'icon-favorite_border'
        });
        this.favorite.on('fill', () => {

            this.favIcon = 'icon-favorite_fill'
        });
        this.favorite.on('update', () => {
            this.update();
        });
        this.selectRowLocal = (e) => {
            this.selectRow(e, this.root.id);
            this.checkWebStorage(e);
        }
        this.trigger_open_popup = (e) => {
            this.popup.trigger('open_popup', e)
        }

        this.sendToShareContent = (e) => {
            this.shareContent(e, this.roqyaCat);
        };
        this.setData = () => {
            this.getData(this.roqyaCat);
            this.zakroon.one('roqya complete', (res) => {

                this.azkar = res;

                this.update()
                this.resetSubHight(0);
            })
        }
        this.getQuran = (e) => {
            this.roqyaCat = "roqya_q";
            this.removeActive(this.refs.category, e)
            this.contentChange = ' change2'
            this.setData();

        }

        this.getSunna = (e) => {
            this.roqyaCat = "roqya_s";
            this.removeActive(this.refs.category, e)
            this.contentChange = ' change1'
            this.setData();
        }
        this.on('mount', () => {
            this.setData();

        })
});
riot.tag2('search-box', '<button class="icon-search" onclick="{runSearch}"><span>إبحث</span></button>', '', '', function(opts) {

        this.runSearch = () => {
            this.search.trigger("open_search_page")
            route('search');
        }

});

riot.tag2('search_results', '<div class="head"><h2 class="sr-only">البحث</h2><div class="search d-flex align-items-center"><button class="icon-arrow-left backBtn" onclick="{closeSearch}"><span class="sr-only">رجوع</span></button><label for="search-field" class="sr-only">ادخل كلمة البحث</label><input id="search-field" class="px-2 border-0" type="search" placeholder="إبحث" onkeyup="{startSearch}" lang="ar"><button class="icon-close resetBtn" onclick="{resetSearch}" if="{showRestBtn}"><span class="sr-only">مسح</span></button></div></div><div id="results"><ol class="staple"><li class="noSearch text-center border-0"> ابحث بكلمة <br><span class="h6"> مثل: </span><span class="h6 cB1"> مطر، صلاة، صيام، نوم، حزن ... </span></li><li class="noSearch2 d-none text-center border-0"> لا يوجد نتائج! <br><span class="h6"> ابحث بكلمة مثل: </span><span class="h6 cB1"> مطر، صلاة، صيام، نوم، حزن ... </span></li><virtual each="{name, i in azkar}"><li onclick="{selectRow}"> {name} </li></virtual></ol></div>', '', '', function(opts) {

        let ref = document.querySelector('#' + this.root.id + ' .staple');
        let ref_search_input = document.querySelector('#' + this.root.id + ' input');
        let azkarTmp, azkarTmpSearch = new Array;
        let _msg1 = "";
        let _msg2 = "";
        this.showRestBtn = false;

        this.resetSearch = (e) => {
            ref_search_input.value = "";

            this.showRestBtn = false;
            this.azkar = new Array;
            _msg1.classList.remove('d-none');
            _msg2.classList.add('d-none');
            this.update()
        }
        this.trigger_open_search_sub = (e) => {
            this.search.trigger('open_search_sub_fromsearch', e)
            route('popup');

        }
        this.selectRow = (e) => {

            this.removeSelect('search_results', e)
            this.trigger_open_search_sub(e);
        }

        this.closeSearch2 = () => {

            this.resetSearch(e);
            route(document.querySelector('nav.nav .active').attributes['data-name'].value);
        };
        this.closeSearch = () => {
            this.root.classList.add('closeAnim');
            setTimeout(this.closeSearch2, 400);
            this.resetSubHight('flex');

        };
        filterResult = (word) => {
            this.azkar = new Array;

            azkarTmpSearch.forEach((value, index) => {
                if (azkarTmpSearch[index].find.includes(word)) {

                    if (this.azkar.indexOf(azkarTmpSearch[index].cat) === -1) {
                        this.azkar.push(azkarTmpSearch[index].cat)
                    }
                } else {

                    if (this.azkar.length === 0) {

                        _msg2.classList.remove('d-none');

                        this.update()
                    } else {
                        if (this.azkar.length > 0) {

                            _msg2.classList.add('d-none');

                            this.update()
                        }

                    }

                }

            })
        };
        this.startSearch = (e) => {
            let word = e.target.value;

            if (word.length > 0 && word !== ' ') {
                this.showRestBtn = true;
                filterResult(e.target.value);
                _msg1.classList.add('d-none');
            } else {
                this.resetSearch(e);
                _msg1.classList.remove('d-none');
                _msg2.classList.add('d-none');
            }

            this.update()

        };
        this.on('mount', () => {
            ref = document.querySelector('#' + this.root.id + ' .staple');
            ref_search_input = document.querySelector('#' + this.root.id + ' input');
            _msg1 = document.querySelector('.noSearch');
            _msg2 = document.querySelector('.noSearch2');

            this.root.classList.add('closeAnim');
            this.search.on("open_search_page", () => {

                this.root.classList.remove('closeAnim');
                this.resetSubHight('none');
                ref_search_input.focus();

                this.getData('duaa');
                this.zakroon.one('search complete', (res, duaa2) => {

                    azkarTmpSearch = res;

                });
            });

        })

});


riot.tag2('search_sub', '<div class="heading d-flex justify-content-between align-items-center flex-row-reverse"><button class="icon-close closeBtn" onclick="{close_search_sub}"><span class="sr-only">أغلق</span></button><span class="title d-inline-block text-center">{title}</span></div><div class="results"><ol class="staple"><virtual each="{azkar}"><li onclick="{selectRowLocal}"><span> {zekr} </span><span class="count"> {this.updateCount(count)} </span><span class="reference"> {this.updateRef(ref,cat)} </span><span class="description"> {desc} </span><div class="meta d-flex justify-content-between align-items-center"><button class="icon-share share d-none" onclick="{sendToShareContent}"><span>شارك</span></button><input type="button" class="counter d-none" data-count="{count}" data-value="0" onclick="{counterClick}" riot-value="{counter}"><a class="fav text-left" title="المفضلة" onclick="{fav}" show="{checkWebStorage}"><span>{favText}</span><span class="{favIcon} icon" aria-hidden="true"></span></a></div></li></virtual></ol></div>', '', '', function(opts) {
        let routefrom = 'search';
        let azkarTmp = new Array;
        this.counter = "عداد";
        this.favText = 'المفضلة';

        this.favorite.on('border', () => {

        });
        this.favorite.on('fill', () => {

        });
        this.favorite.on('update', () => {
            this.update();
        });
        this.selectRowLocal = (e) => {

            this.selectRow(e, this.root.id);
            this.checkWebStorage(e);
        };

        this.setData = () => {
            this.getData(this.title);
            this.zakroon.one('search_sub complete', (res, duaa2) => {

                this.azkar = res;

                this.update()
            })
        };

        this.sendToShareContent = (e) => {
            this.shareContent(e, this.azkarCat);
        };

        this.trigger_open_popup = (e) => {
            this.popup.trigger('open_popup', e)
        }

        this.close_search_sub2 = () => {
            this.root.hidden = true;
            this.azkar = [];
            route(routefrom);

            this.update()
            this.resetSubHight('flex', 'desktop');

        }
        this.close_search_sub = () => {
            this.root.classList.add('closeAnim')
            setTimeout(this.close_search_sub2, 400);
        }

        this.on('mount', () => {
            let scroller = document.querySelector('#scroller')
            this.root.hidden = true;
            this.search.on("open_search_sub_fromsearch", (e) => {
                this.root.hidden = false;

                this.title = e.item.name;
                this.setData();
                this.root.classList.remove('closeAnim')
                this.update();
                this.resetSubHight('none');

            })
            this.search.on("open_search_sub", (e) => {

                this.root.hidden = false;
                routefrom = 'duaa'
                this.title = e.item.name;
                this.setData();
                this.root.classList.remove('closeAnim')
                this.update();
                this.resetSubHight('none', 'desktop');

            })

        })

});

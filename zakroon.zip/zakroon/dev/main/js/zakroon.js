
// gsap.to('.navbar-brand',{duration:5, x:5, opacity:0.5,ease:"back"});
// gsap.to(window, {duration: 1, scrollTo: 600});

riot.mixin({

    zakroon: riot.observable(),
    popup: riot.observable(),
    search: riot.observable(),
    favorite: riot.observable(),
    sliding: riot.observable(),
    navi: riot.observable(),
    setting: riot.observable(),

    saveCurrentScrollPosition:
        function (el) {
            // let _csp = 0;
            //    check if browser support sessionStorage
            if (typeof (Storage) !== "undefined") {
                // Code for localStorage/sessionStorage.
                sessionStorage.setItem('lastScrollPos', el);
                // console.log('last scroll position:', el)
            }
            //    return saved scroll position

        },

    readCurrentScrollPosition:
        function () {
            let _csp = 0;
            //    check if browser support sessionStorage
            if (typeof (Storage) !== "undefined") {
                // Code for localStorage/sessionStorage.
                _csp = sessionStorage.getItem('lastScrollPos');
                // console.log('last scroll position:', content.scrollTop)
            }
            //    return saved scroll position
            return _csp;
        },

    checkSettingIcon:
        function () {
            let return_value;
            let settingIcon = localStorage.getItem("settingIcon");
            if (settingIcon !== null) {
                // console.log('settingIcon:', settingIcon);
                if (settingIcon == 'icon-sun') {
                    document.querySelector('#app').classList.add('dark');
                }
                return_value = settingIcon;
            } else {
                return_value = 'icon-moon'
            }

            return return_value;
        },

    isSupportWebStorage:
        function (e) {
            if (typeof (Storage) !== "undefined") {
                this.setting.trigger('show');
                this.checkSettingIcon();
            } else {
                // Sorry! No Web Storage support..
                this.setting.trigger('hide');
            }
        },

    setSettingIcon:
        function (e) {
            let el = e.target;
            let cIcons = el.classList;
            let cIcon = cIcons[1];
            if (cIcon === 'icon-moon') {
                document.querySelector('#app').classList.add('dark');
                localStorage.setItem("settingIcon", 'icon-sun');
                el.classList.replace('icon-moon', 'icon-sun');
            } else {
                document.querySelector('#app').classList.remove('dark');
                localStorage.setItem("settingIcon", 'icon-moon');
                el.classList.replace('icon-sun', 'icon-moon');
            }
        },

    addScroll:
        function () {
            window.scrollTo(0, 0);
            // console.log('added');
        },
    resetSubHight:
        function (h, device = '') {

            //on desktop there is an issue if scroll not reset once popup open
            //it think I need to read last scroll after popup close on desktop

            // console.log('from sub reset heieght ')
            // only if desktop
            let subcontent = document.getElementById('subcontent');
            let _activeEl = document.querySelector('nav.nav a.active').getAttribute('data-name');
            let scroller = document.querySelector('#scroller');
            //todo need inhancment by adding extra param
            if (document.getElementById('app').classList.contains('desktop')) {
                if (device === '' || device !== 'mobile') {
                    if (h === 'none') {
                        // h = 1 + 'px';
                        window.addEventListener('scroll', this.addScroll, false);
                        window.scrollTo(0, 0);
                    }
                    if (h === 'flex') {
                        // h = 1 + 'px';
                        // console.log('from flex');
                        window.removeEventListener('scroll', this.addScroll, false);
                    }
                    if (h === 0) {
                        subcontent.style.height = document.getElementById(_activeEl).offsetHeight + 200 + 'px';
                    }


                    // console.log(_activeEl, h);
                }

            }
            // not desktop
            else {
                if (device === '' || device !== 'desktop') {
                    // this.saveCurrentScrollPosition();
                    subcontent.style.height = document.getElementById(_activeEl).offsetHeight + 200 + 'px';
                    scroller.scrollTop = 0;
                }

            }
        },


    checkWebStorage:
        function (e) {
            // console.log('e:', e);
            // to show or hide icon
            // console.log('path[0]:', _path);
            // console.log('from check webstorage: ', e);
            let _path = e.target;

            if (typeof (Storage) !== "undefined") {
                // Code for localStorage/sessionStorage.

                if (_path.tagName === 'LI') {
                    _path = ((_path.lastChild).lastChild).lastChild;
                } else {
                    _path = _path.parentElement;
                    if (_path.tagName === 'LI') {
                        _path = ((_path.lastChild).lastChild).lastChild;
                    }
                    // console.log('_path parent should be LI:', _path);
                }

                // console.log('_path:', _path);


                if (this.isFav(e) !== false) {
                    // this.icon_fav_type = "icon-favorite";
                    // console.log('from storage: target: ', _path);
                    if (_path.classList.contains('icon')) {
                        _path.classList.add("icon-favorite_fill");
                        this.favorite.trigger('fill');
                    }


                } else {
                    if (_path.classList.contains('icon')) {
                        _path.classList.add("icon-favorite_border");
                        this.favorite.trigger('border');
                    }


                }
                return true
            } else {
                // Sorry! No Web Storage support..
                return false
            }
        },
    isFav:
        function (e) {
            //just let me know by yes or no to set type of icon
            let return_value;
            let myFav = localStorage.getItem("myFav");
            if (myFav !== null) {
                // console.log('my fav:', myFav);
                //    search for zekr
                let res = JSON.parse(myFav);
                if (res.find(o => o.zekr === e.item.zekr) !== undefined) {
                    // console.log('filter:', res.filter(o => o.zekr === e.item.zekr));
                    return_value = true;
                } else {
                    return_value = false
                }


            } else {
                // console.log('my fav:', myFav);
                return_value = false;
            }

            return return_value;
        },
    removeFromFav:
        function (e) {
            let myFav = localStorage.getItem("myFav");
            let res = [];
            let elIndex;
            res = JSON.parse(myFav);
            elIndex = res.findIndex(o => o.zekr === e.item.zekr);
            // console.log('index of: ', res.findIndex(o => o.zekr === e.item.zekr));
            res.splice(elIndex, 1);
            localStorage.setItem("myFav", JSON.stringify(res));
            // console.log('from remove fav:', e.target.parentNode.parentElement)
            e.target.parentNode.parentElement.classList.add('delete');
            if (e.target.nodeName === 'SPAN') {
                if (e.target.classList.length === 0) {
                    e.target.parentElement.children[1].classList.remove('icon-favorite_fill');
                    e.target.parentElement.children[1].classList.add('icon-favorite_border');
                } else {
                    e.target.classList.remove('icon-favorite_fill');
                    e.target.classList.add('icon-favorite_border');
                }
            } else {
                e.target.children[1].classList.remove('icon-favorite_fill');
                e.target.children[1].classList.add('icon-favorite_border');
            }
            this.favorite.trigger('border');

            let _activeEl = document.querySelector('nav.nav a.active').getAttribute('href');

            if (_activeEl === '/favorite')
                this.resetSubHight2(false);
        },
    addToFav:
        function (e) {
            let myFav = localStorage.getItem("myFav");
            let res = [];
            // console.log('e:',e);
            // console.log('e.target:',e.target);
            // console.log('e.path:',e.path);

            //find cat of duaa
            let _path = e.target;
            if (e.item.cat === undefined) {

                while (_path.tagName !== 'OL') {
                    _path = _path.parentElement;
                }
                // console.log('_path:', _path);
                _path = (_path.previousSibling).firstChild;
                // console.log('_path sibling:', _path);

                _current_cat = _path.querySelector('span.active').innerHTML;
                // if (_path.firstChild.contains(_q)) {
                //
                // }
                switch (_current_cat) {
                    case 'أذكار الصباح':
                        e.item.cat = 'azkar_s';
                        break;
                    case 'أذكار المساء':
                        e.item.cat = 'azkar_m';
                        break;
                    case 'من السنة':
                        e.item.cat = 'roqya_s';
                        break;
                    case 'من القرآن':
                        e.item.cat = 'roqya_q';
                        break;
                }
            }

            if (myFav == null) {
                res[0] = e.item;

            } else {
                res = JSON.parse(myFav);
                res.push(e.item)
            }
            localStorage.setItem("myFav", JSON.stringify(res));
            // console.log('from add to fav:', e.target.nodeName);

            _path = e.target.tagName;

            if (_path === 'A') {
                _path = e.target.lastChild;
            } else {
                if (e.target.parentElement.tagName === 'A') {
                    _path = e.target.parentElement.lastChild;
                }
            }

            // console.log('_path:', _path);

            _path.classList.remove('icon-favorite_border');
            _path.classList.add('icon-favorite_fill');


            this.favorite.trigger('fill');

            // console.log('add to fav:', myFav);
            // console.log('my fav:', myFav);
        },
    removeSelect:
        function (tagName, e) {
            // console.log(e.item)
            // console.log(this.isFav(e))
            // if (!this.isFav(e)) {
            //
            // }
            let parentNode = document.querySelector('#' + tagName + ' .staple')
            // console.log('parentNode:',parentNode)
            _allChild = parentNode.children;
            _length = _allChild.length;
            // console.log('all child:',_allChild);
            for (i = 0; i < _length; i++) {
                _allChild[i].classList.remove('select');
            }
            // _allChild.forEach((val, index) => {
            //     _allChild[index].classList.remove('select');
            // })
            if (e.target.nodeName === 'SPAN') {
                e.target.parentElement.classList.add("select");
            } else {
                e.target.classList.add("select");
            }

            try {
                let _count = document.querySelector('#' + tagName + ' .select span.count');
                let _reference = document.querySelector('#' + tagName + ' .select span.reference');
                let _description = document.querySelector('#' + tagName + ' .select span.description');
                if (_count.innerText === ' ' || _count.innerText === '' || _count.innerText.length <= 1) {
                    _count.setAttribute('hidden', '');
                }
                if (_description.innerText === ' ' || _description.innerText === '' || _description.innerText.length <= 1) {
                    _description.setAttribute('hidden', '');
                }
                // console.log(_count.innerText);
                // console.log(_description);
            } catch (e) {

            }

        },


    updateCount: function (count) {
        let _result = '';
        if (count >= 3) {
            if (count >= 100) {
                _result = '( ' + count + ' ' + 'مرة' + ' )'
            } else {
                _result = '( ' + count + ' ' + 'مرات' + ' )'
            }
        }
        return _result;
    },

    updateDesc: function (desc) {
        if (desc === '' || desc === ' ' || desc === undefined) {
            return '';
        } else
            return desc;
    },

    updateRef: function (ref, cat) {
        // console.log('ref:', ref);
        // console.log('cat:', cat);

        // check if from Quran

        if (cat === 'أذكار المساء' || cat === 'أذكار الصباح' || cat === 'الرُّقية الشرعية من السنة النبوية' || cat === 'الرُّقية الشرعية من القرآن الكريم') {
            if (ref === '' || ref === ' ' || ref === undefined) {
                return ref;
            } else {
                if (ref.includes('سورة') || ref.includes('آية') || ref.includes('البقرة')) {
                    return '[' + ref + ']';
                } else {
                    return '[' + 'أخرجه: ' + ref + ']';
                }
            }

        } else {
            if (ref === '' || ref === ' ' || ref === undefined) {
                return '[' + 'حصن المسلم | سعيد بن وهف القحطاني' + ']';
            } else if (ref.includes('سورة') || ref.includes('آية') || ref.includes('البقرة')) {
                return '[' + ref + ']';
            } else {
                return '[' + 'أخرجه: ' + ref + ']';
            }

        }

    },

    shareTitle: function (cat) {
        let _title = '';
        switch (cat) {
            case 'azkar_s':
                _title = 'من أذكار الصباح';
                break;
            case 'azkar_m':
                _title = 'من أذكار المساء';
                break;
            case 'roqya_q':
                _title = 'من الرقية بالقرآن';
                break;
            case 'roqya_s':
                _title = 'من أدعية الرقية';
                break;
            default:
                if (cat === 'من دعاء النبي صلى الله عليه وسلم') {
                    _title = cat;
                } else {
                    _title = 'من ' + cat;
                }

        }
        return _title;

    },

    shareText: function (cat, zekr, count, description) {
        // console.log(cat);
        if (cat === 'من الرقية بالقرآن') {
            return cat + '\n\n' + zekr + '\n\n';
        } else {
            if (count === 1 || count === '') {
                if (description !== '' || description !== undefined)
                    return cat + '\n\n' + zekr + '\n\n' + description + '\n\n';
                else
                    return cat + '\n\n' + zekr + '\n\n';
            } else {
                if (description !== '' || description !== undefined)
                    return cat + '\n\n' + zekr + ' ' + this.updateCount(count) + '\n\n' + description + '\n\n';
                else
                    return cat + '\n\n' + zekr + ' ' + this.updateCount(count) + '\n\n';
            }
        }


    },

    shareContent:
        function (e, cat) {
            // console.log('e:', e);
            let _cat = '';
            e.stopPropagation();
            if (cat === undefined) {
                _cat = e.item.cat;
            } else {
                _cat = cat;
            }
            // console.log('item', e.item)
            // console.log('cat:', _cat);
            let _title = this.shareTitle(_cat);
            let _text = this.shareText(_title, e.item.zekr, e.item.count, e.item.desc);
            // console.log('share title:', _title);
            // console.log('share text:', _text);
            // console.log('share item cat:', e.item.cat);
            if (navigator.share) {
                navigator.share({
                    title: _title,
                    text: _text,
                    url: 'https://zakroon.com/',
                })
                    .then(() => console.log('Successful share'))
                    .catch((error) => console.log('Error sharing', error));
            }

        },

    fav: function (e) {
        e.stopPropagation();
        // console.log('fron fav():', e.target);
        //check if A or span
        let _path = e.target.tagName;
        if (_path === 'A') {
            _path = e.target.lastChild;
        } else {
            if (e.target.parentElement.tagName === 'A') {
                _path = e.target.parentElement.lastChild;
            }
        }

        if (_path.classList.contains("icon-favorite_border")) {
            this.addToFav(e);
        } else if (_path.classList.contains("icon-favorite_fill")) {
            this.removeFromFav(e);
        }


        this.favorite.trigger('update');

    },

    selectRow:
        function (e, tagName) {
            // if selected not select again
            // let _path = e.target;
            let _path = e.target;

            let _activeEl = document.querySelector('nav.nav a.active').getAttribute('data-name');
            let _active_el_id = "#" + _activeEl + " li.select";

            if (_path.tagName !== 'LI') {
                _path = _path.parentElement;

            }
            if (_path.tagName === 'LI') {

                if (!_path.classList.contains('select')) {
                    this.removeSelect(tagName, e);

                    //reset counter

                    let _meta = _path.querySelector('.meta');
                    let _counter = _path.querySelector('.meta .counter');
                    let _share = _path.querySelector('.meta .share');
                    let _fav = _path.querySelector('.meta .fav');
                    _meta.classList.remove('fullH');
                    _share.classList.remove('off');
                    _fav.classList.remove('off');
                    // _path.querySelector('.meta fav').classList.remove('off');
                    _counter.dataset.value = 0;
                    _counter.value = "عداد";
                    _counter.classList.remove('on');
                    // console.log('_counter:', _counter);


                    this.resetSubHight2();

                    // console.log("location:",location);
                    // console.log("active el id:",_active_el_id);
                    if (location.pathname === '/azkar' || location.pathname === '/roqya' || location.pathname === '/favorite'){
                        // let _app = document.querySelector('#app');
                        if (document.getElementById('app').classList.contains('desktop')) {
                            //for desktop
                            gsap.to(window, {duration: 0.35, scrollTo: {y: _active_el_id, offsetY: 200}});
                            gsap.to(window, {duration: 0.25, delay: 0.35, scrollTo: {y: _active_el_id, offsetY: 90}});

                        } else {
                            //if not desktop
                            gsap.to("#scroller", {duration: 0.35, scrollTo: {y: _active_el_id, offsetY: 90}});
                            gsap.to("#scroller", {
                                duration: 0.25,
                                delay: 0.35,
                                scrollTo: {y: _active_el_id, offsetY: 0}
                            });
                        }
                    }
                    if (location.pathname === '/popup'){
                        gsap.to("#search_sub .results", {duration: 0.35, scrollTo: {y: "#search_sub .results li.select", offsetY: 90}});
                            gsap.to("#search_sub .results", {
                                duration: 0.25,
                                delay: 0.35,
                                scrollTo: {y: "#search_sub .results li.select", offsetY: 0}
                            });

                    }


                    //for results
                    /*gsap.to("#search_sub .staple", {duration: 0.35, scrollTo: {y: _active_el_id, offsetY: 200}});
                    gsap.to("#search_sub .staple", {duration: 0.25, delay:0.35, scrollTo: {y: _active_el_id, offsetY: 90}});
*/


                    // console.log('path:',_path);
                }
            }


        },
    removeActive:
        function (parentNode, e) {

            _allChild = parentNode.childNodes;
            // console.log('all child:',_allChild);
            _allChild.forEach((val, index) => {
                _allChild[index].classList.remove('active');
            });
            e.target.classList.add("active");

        },

    getData:

        function (rquested_term) {
            this.zakroon.trigger('start');
            // console.log('requsted term : ', rquested_term);
            const _url_local = 'http://localhost:3000/main/data/';
            const _url_prod = 'https://zakroon.com/main/data/';
            let _url = '';
            let _file = '';
            let _ext = '.json';
            let _duaa2 = new Array;
            let _req_value = ['duaa', 'azkar_s', 'azkar_m', 'roqya_s', 'roqya_q']
            if (_req_value.includes(rquested_term)) {
                _file = rquested_term;
            } else
                _file = 'duaa';

            //check for browser url
            // console.log("location:",location.origin);
            _url = location.origin + '/main/data/';

            /*if (location.hostname === 'localhost') {
                _url = _url_local
            } else {
                _url = _url_prod
            }*/

            let xhr = new XMLHttpRequest();
            // console.log(_url + _file + _ext);
            xhr.open('GET', _url + _file + _ext);
            xhr.onload = () => {

                // Decode response (JSON)
                let res = (xhr.status === 200) ? JSON.parse(xhr.responseText) : null;
                // console.log('res : ', res);


                switch (rquested_term) {
                    case 'azkar_s':
                        this.zakroon.trigger('azkar complete', res);
                        break;
                    case 'azkar_m':
                        this.zakroon.trigger('azkar complete', res);
                        break;
                    case 'roqya_q':
                        this.zakroon.trigger('roqya complete', res);
                        break;
                    case 'roqya_s':
                        this.zakroon.trigger('roqya complete', res);
                        break;
                    case 'duaa':

                        res.forEach((val, index) => {
                            if (_duaa2.indexOf(res[index].cat) === -1) {
                                _duaa2.push(res[index].cat);
                            }
                        });
                        this.zakroon.trigger('duaa complete', res, _duaa2);
                        this.zakroon.trigger('search complete', res, _duaa2);
                        // console.log('duaa2:', _duaa2);
                        // this.zakroon.trigger('duaa complete', res);
                        // this.zakroon.trigger('search complete', return_data);
                        // this.zakroon.trigger('search_sub complete', return_data)
                        break;
                    // case 'duaa-full':
                    //     this.zakroon.trigger('search complete', res);
                    //     break;
                    default:
                        return_data = res.filter(o => o.cat === rquested_term);

                        this.zakroon.trigger('search_sub complete', return_data);
                    // console.log('returend data:', return_data);
                }


                // Notify of new results
                this.zakroon.trigger('complete', res)
            };
            xhr.send()
        },

    counterClick:
        function (e) {
            //current value
            let _path = e.target;

            /*if (_path === 'INPUT') {
                _path = e.target;
                // _path = e.target.childNodes[0];
                // console.log('new path:', _path);
            }*/
            // else {
            //
            // }
            let _parent = _path.parentElement;
            _parent.classList.add('fullH');
            // console.log('_parent:',_parent);
            _parent.firstElementChild.classList.add('off');
            _parent.lastElementChild.classList.add('off');

            //check if has 'on' or not
            _path.classList.add('on');
            let _c_v = Number(_path.dataset.value);
            //max value
            let _m_v = Number(_path.dataset.count);
            if (isNaN(_m_v)) _m_v = 1;
            // console.log('_m_v:', _m_v);
            if (_c_v < _m_v) {
                _c_v += 1;
                if (navigator.vibrate)
                    navigator.vibrate(50);
                // if(_c_v)
                _path.dataset.value = _c_v;
                _path.value = _c_v;
            }
            //max last number
            if (_c_v >= _m_v) {
                if (_c_v === _m_v) {
                    _c_v += 1;
                    _path.dataset.value = _c_v;
                    // _path.value = _c_v;
                } else {
                    if (_path.dataset.value > _path.value) {
                        _path.dataset.value = _c_v;
                        _path.value = _c_v;
                    } else {
                        _c_v += 1;
                        _path.dataset.value = _c_v;
                        _path.value = _c_v;
                    }

                }
                // console.log('full');
                //    animate + vibrate + change color
                if (navigator.vibrate)
                    navigator.vibrate(300);
                _path.classList.add('pulse');
                setTimeout(() => {
                    _path.classList.remove('pulse');
                }, 300)

            }

            this.update();
        },

    //to reset height of selected page(tab) also after select items and counters

    resetSubHight2:
        function (extra = true) {
            // console.log('from main reset heieght ')
            let _activeEl = document.querySelector('nav.nav a.active').getAttribute('data-name');
            if (extra)
                subcontent.style.height = document.getElementById(_activeEl).offsetHeight + 200 + 'px';
            else
                subcontent.style.height = document.getElementById(_activeEl).offsetHeight + 'px'
        }

// checkCounter:
//     function (counter) {
//         console.log('counter:', counter);
//         let r = false;
//         (counter > 1) ? r = true : r = false;
//         console.log('r:',r);
//         return r;
//     }

})
;


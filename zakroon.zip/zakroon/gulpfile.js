// Gulp.js configuration

// include gulp and plugins
var
    gulp = require('gulp'),
    newer = require('gulp-newer'),
    concat = require('gulp-concat'),
    preprocess = require('gulp-preprocess'),
    htmlclean = require('gulp-htmlclean'),
    // imagemin = require('gulp-imagemin'),
    // imageminJpegtran = require('imagemin-jpegtran'),
    // imageminOptipng = require('imagemin-optipng'),
    // imageminWebp = require('imagemin-webp'),
    // recompress = require('imagemin-jpeg-recompress'),
    // webp = require('gulp-webp'),
    // cache = require('gulp-cache'),
    // flatten = require('gulp-flatten'),
    // imageResize = require('gulp-image-resize'),
    // imacss = require('gulp-imacss'),
    sass = require('gulp-sass'),
    // stripdebug = require('gulp-strip-debug'),
    // uglify = require('gulp-uglify'),
    minify = require('gulp-minify'),
    // uncss = require('gulp-uncss'),
    size = require('gulp-size'),
    del = require('del'),
    // critical = require('critical'),
    // rev = require('parsec-gulp-rev'),
    // revCollector = require('gulp-rev-collector'),
    purgecss = require('gulp-purgecss'),
    sitemap = require('gulp-sitemap'),
    minifyInline = require('gulp-minify-inline'),
    // runSequence = require('run-sequence'),
    workboxBuild = require('workbox-build'),
    pkg = require('./package.json'),
    browserSync = require('browser-sync').create(),
    reload = browserSync.reload;


// file locations
var
    devBuild = ((process.env.NODE_ENV || 'development').trim().toLowerCase() !== 'production'),

    source = 'dev/',
    dest = 'prod/',

    html = {
        in: [source + '*.html', source + '*.shtml'],
        watch: [source + '*.html', source + '*.shtml', source + 'template/**/*'],
        out: dest,
        context: {
            devBuild: devBuild,
            author: pkg.author,
            version: pkg.version
        }
    },


    images = {
        in: source + 'main/img/**/*',
        out: dest + 'main/img/'
    },

    icons = {
        in: source + 'main/icons/**/*',
        out: dest + 'main/icons/'
    },

    copy_others = {
        // in: [source + 'sw.js', source + 'main/data/**/*'],
        in: [source + 'main/data/**/*'],
        out: dest + ''

    },
    // imguri = {
    //     in: source + 'main/images/inline/*',
    //     out: source + 'main/scss/images/',
    //     filename: '_datauri.scss',
    //     namespace: 'img'
    // },

    css = {
        // in: source + 'main/scss/*.scss',
        in: source + 'main/scss/*.scss',
        // watch: [source + 'main/scss/**/*', '!' + imguri.out + imguri.filename],
        watch: [source + 'main/scss/**/*'],
        watchCSS: [dest + 'main/css/**/*'],
        out: dest + 'main/css/',
        sassOpts: {
            outputStyle: 'compressed', /*'nested',*/
            imagePath: '../images',
            precision: 3,
            errLogToConsole: true
        }
    },

    fonts = {
        in: source + 'main/fonts/**/*',
        out: dest + 'main/fonts/'
    },
    vendor = {
        in: source + 'main/vendor/*.*',
        out: dest + 'main/vendor/'
    },
    others = {
        in: [source + 'robots.txt', source + 'sitemap.xml'],
        out: dest
    },
    js = {
        // in: source + 'main/js/*',
        // in: [source + 'main/js/ua-parser.min.js', source + 'main/js/main.js'],
        in: [source + 'main/js/*.*'],
        out: dest + 'main/js/'
        // filename: 'main.js'
    };

// show build type
console.log(pkg.name + ' ' + pkg.version + ', ' + (devBuild ? 'development' : 'production') + ' build');

// clean the build folder
gulp.task('clean', function (done) {
    del([
        dest + '*'
    ]);
    done();
});

// build HTML files
gulp.task('html', function () {
    var page = gulp.src(html.in).pipe(preprocess({context: html.context}));
    // if (!devBuild) {
    page = page
        .pipe(size({title: 'HTML in'}))
        .pipe(htmlclean())
        .pipe(minifyInline())
        .pipe(size({title: 'HTML out'}))
    // .pipe(revCollector());
    // }
    return page.pipe(gulp.dest(html.out));
});


// manage images
gulp.task('images', function () {
    return gulp.src(images.in)
        // .pipe(newer(images.out))
        .pipe(size({title: 'images in'}))
        //.pipe(imagemin())
        // .pipe(webp())

        // .pipe(imagemin([
        //     imagemin.gifsicle(),
        //     recompress({
        //         loops: 4,
        //         min: 60,
        //         max: 85,
        //         quality: 'high'
        //     }),
        //     imagemin.optipng()
        //     //imagemin.svgo()
        // ]))
        .pipe(size({title: 'images out'}))
        .pipe(gulp.dest(images.out));
});

// copy icons
gulp.task('icons', function () {
    return gulp.src(icons.in)
        // .pipe(newer(icons.out))
        .pipe(gulp.dest(icons.out));
});


// copy fonts
gulp.task('fonts', function () {
    return gulp.src(fonts.in)
        // .pipe(newer(fonts.out))
        .pipe(gulp.dest(fonts.out));
});


// copy vendors
gulp.task('vendor', function () {
    return gulp.src(vendor.in)
        // .pipe(newer(vendor.out))
        .pipe(gulp.dest(vendor.out));
});

// copy others (other files)
gulp.task('others', function () {
    return gulp.src(others.in)
        // .pipe(newer(others.out))
        .pipe(gulp.dest(others.out));
});

gulp.task('sitemap', function (done) {
    gulp.src(source + '**/*.html', {
        read: false
    })
        .pipe(sitemap({
            siteUrl: 'https://zakroon.com'
        }))
        .pipe(gulp.dest(source));
    done();
});

// compile Sass
// gulp.task('sass', ['imguri'], function() {
gulp.task('sass', function () {
    return gulp.src(css.in)
        .pipe(sass(css.sassOpts))
        .pipe(gulp.dest(css.out + 's/'));
});

gulp.task('purgecss', function () {
    return gulp
        .src(css.out + 's/*.css')
        .pipe(
            purgecss({
                content: [html.out + '*.html', source + 'main/tag/*.tag'],
                // whitelistPatterns: [/select/, /show/, /active/]
                whitelistPatterns: [/select/, /headsmall/, /closeAnim/, /desktop/, /android/, /dark/, /delete/, /off/,/pulse/,/fullH/],
                whitelist: ['icon-sun','icon-moon']
            })
        )
        .pipe(gulp.dest(css.out))
});

gulp.task('js', function () {
    return gulp.src(js.in)
        .pipe(minify({
            ext: {
                // src: '-debug.js',
                min: '.js'
            },
            noSource: true
        }))
        // .pipe(newer(js.out))
        .pipe(gulp.dest(js.out));
});

gulp.task('copy_others', function () {
    return gulp.src(copy_others.in, {base: 'dev'})
    // .pipe(newer(copy_others.out))
        .pipe(gulp.dest(copy_others.out));
});


gulp.task('serve', function (done) {
    browserSync.init({
        server: './prod',
        baseDir: "./",
        browser: ["Chromium", "firefox"],
        open: false,
        rewriteRules: [
            {
                match: /(azkar|duaa|roqya|favorite|search|popup)/g,
                fn: function (req, res, match) {
                    return 'index.html';
                }
            }
        ]
        // https: true,
        // proxy: "zakroon.dev"
    });
    // gulp.watch("**/*").on("change", reload);
    done();

});

gulp.task('reload', function (done) {
    browserSync.reload();
    done();
});

gulp.task('service-worker', (done) => {

    // return workboxBuild.injectManifest({
    //     swSrc: 'dev/sw.js',
    //     swDest: 'prod/sw.js',
    //     globDirectory: 'prod',
    //     globPatterns: [
    //         '**\/*.{js,json,css,html,png,jpg,gif,svg,woff,woff2,ttf,ico}',
    //     ],
    //     globIgnores: [
    //         'main/icons/*.png',
    //         'main/icons/ios/*.png',
    //         'main/icons/windows/*.png',
    //         'main/icons/windows10/*.png',
    //         'main/css/s/*.css'
    //     ],
    //     // navigateFallback: '/',
    //
    //     templatedUrls: {
    //         '/': '/index.html',
    //         // '/azkar': '/',
    //         // '/duaa': '/',
    //         // '/roqya': '/',
    //         // '/favorite': '/',
    //         // '/search': '/',
    //         // '/popup': '/'
    //         //
    //         // '/': '/index.html',
    //         '/azkar': '/index.html',
    //         '/duaa': '/index.html',
    //         '/roqya': '/index.html',
    //         '/favorite': '/index.html',
    //         '/search': '/index.html',
    //         '/popup': '/index.html'
    //     }
    //
    //
    // }).then(({count, size, warnings}) => {
    //     // Optionally, log any warnings and details.
    //     warnings.forEach(console.warn);
    //     console.log(`${count} files will be precached, totaling ${size} bytes.`);
    // });

    return workboxBuild.generateSW({
        // swSrc: 'dev/sw.js',
        importWorkboxFrom: 'cdn',
        swDest: 'prod/sw.js',
        globDirectory: 'prod',
        globPatterns: [
            '**\/*.{js,json,css,html,png,jpg,gif,svg,woff,woff2,ico}',
        ],
        globIgnores: [
            'main/icons/*.png',
            'main/icons/ios/*.png',
            'main/icons/windows/*.png',
            'main/icons/windows10/*.png',
            'main/css/s/*.css'
        ],
        skipWaiting: true,
        clientsClaim: true,
        navigateFallback: 'index.html',
        directoryIndex: 'index.html',
        cacheId: 'zakroon',
        // cleanupOutdatedCaches: true,
        templatedURLs: {
            '/': 'index.html'
            // '/azkar': '/',
            // '/duaa': '/',
            // '/roqya': '/',
            // '/favorite': '/',
            // '/search': '/',
            // '/popup': '/'

            // '/': '/index.html',
            // '/azkar': '/index.html',
            // '/duaa': '/index.html',
            // '/roqya': '/index.html',
            // '/favorite': '/index.html',
            // '/search': '/index.html',
            // '/popup': '/index.html',
        }

    }).then(({count, size, warnings}) => {
        // Optionally, log any warnings and details.
        warnings.forEach(console.warn);
        console.log(`${count} files will be precached, totaling ${size * 0.000001} MB.`);
    });



});


// gulp.task('all', ['html', 'images', 'icons', 'fonts', 'sass', 'js', 'copy_others', 'vendor', 'purgecss', 'service-worker']);

// gulp.task('all', gulp.series('clean','html', 'images', 'icons', 'fonts', 'sass', 'js', 'copy_others', 'vendor', 'purgecss', 'service-worker','serve'))

gulp.task('all', gulp.series('clean', 'html', 'images', 'icons', 'fonts','sitemap', 'sass', 'js', 'copy_others', 'vendor', 'others','purgecss', 'service-worker'), function (done) {
        done();
});

/*gulp.task('all', gulp.series('clean', 'html', 'images', 'icons', 'fonts','sitemap', 'sass', 'js', 'copy_others', 'vendor', 'others', 'service-worker'), function (done) {
    done();
});*/

gulp.task('default', gulp.series('all'), function (done) {

    // html changes
    gulp.watch(html.watch, gulp.series('all'));
    // gulp.watch(html_ar.watch, ['html_ar','purgecss']);

    // image changes
    gulp.watch(images.in, gulp.series('all'));

    // icon changes
    gulp.watch(icons.in, gulp.series('all'));

    // font changes
    gulp.watch(fonts.in, gulp.series('all'));

    // sass changes
    // gulp.watch([css.watch, imguri.in], ['sass']);
    gulp.watch([css.watch], gulp.series('all'));

    // javascript changes
    gulp.watch(js.in, gulp.series('all'));

    // javascript changes
    gulp.watch(copy_others.in, gulp.series('all'));

    // others changes
    gulp.watch(others.in, gulp.series('all'));

    // vendor changes
    gulp.watch(vendor.in, gulp.series('all'));

    gulp.watch([css.watchCSS], gulp.series('all'));

    // gulp.watch([css.watchCSS], ['service-worker']);
    done();

});


/**
 * Welcome to your Workbox-powered service worker!
 *
 * You'll need to register this file in your web app and you should
 * disable HTTP caching for this file too.
 * See https://goo.gl/nhQhGp
 *
 * The rest of the code is auto-generated. Please don't update this file
 * directly; instead, make changes to your Workbox build configuration
 * and re-run your build process.
 * See https://goo.gl/2aRDsh
 */

importScripts("https://storage.googleapis.com/workbox-cdn/releases/4.3.1/workbox-sw.js");

workbox.core.setCacheNameDetails({prefix: "zakroon"});

workbox.core.skipWaiting();

workbox.core.clientsClaim();

/**
 * The workboxSW.precacheAndRoute() method efficiently caches and responds to
 * requests for URLs in the manifest.
 * See https://goo.gl/S9QRab
 */
self.__precacheManifest = [
  {
    "url": "index.html",
    "revision": "54d26017bb7ead13d8c621a99eaf1f2c"
  },
  {
    "url": "main/css/main_ar.css",
    "revision": "19f7ff21e5cac147a4e36ce2d3a329cd"
  },
  {
    "url": "main/data/azkar_m.json",
    "revision": "5ab6d6c829de2e8e9751faeb998d169e"
  },
  {
    "url": "main/data/azkar_s.json",
    "revision": "aa3bf73d520f834daa46c20262908a6f"
  },
  {
    "url": "main/data/duaa.json",
    "revision": "87adc96772095b596cc13b735f6982f4"
  },
  {
    "url": "main/data/roqya_q.json",
    "revision": "21734c0341b86246c7feeb4a97ae7f96"
  },
  {
    "url": "main/data/roqya_s.json",
    "revision": "b2ce4252f38cb027e95b7143ac37cddd"
  },
  {
    "url": "main/fonts/i7/zakroon_icons.woff",
    "revision": "571953c354b2a4dd1289442a512e9498"
  },
  {
    "url": "main/fonts/NotoNaskhArabic-Regular.woff2",
    "revision": "6d1baa4104fc303c312def13f9cf7d12"
  },
  {
    "url": "main/fonts/Tajawal-Bold.woff2",
    "revision": "b2ecc2cdb4d94447b16461f08278a6e2"
  },
  {
    "url": "main/fonts/Tajawal-Regular.woff2",
    "revision": "677bd84603821389c929685f10f1f234"
  },
  {
    "url": "main/icons/android/android-launchericon-144-144.png",
    "revision": "c1235ed96dc276fd8a604dad2a824cc6"
  },
  {
    "url": "main/icons/android/android-launchericon-192-192.png",
    "revision": "cc4cd957f5511ebf7d7bde9d80e809e0"
  },
  {
    "url": "main/icons/android/android-launchericon-48-48.png",
    "revision": "2f67dc9eec91616ee09c03eaa420e628"
  },
  {
    "url": "main/icons/android/android-launchericon-512-512.png",
    "revision": "73c0b947844e658446da1ec72cf8b95a"
  },
  {
    "url": "main/icons/android/android-launchericon-72-72.png",
    "revision": "434fb9b3afa6d8d09bedca4ab1b468aa"
  },
  {
    "url": "main/icons/android/android-launchericon-96-96.png",
    "revision": "7b62dded37b91a690e342d756166db05"
  },
  {
    "url": "main/icons/chrome/chrome-extensionmanagementpage-48-48.png",
    "revision": "2f67dc9eec91616ee09c03eaa420e628"
  },
  {
    "url": "main/icons/chrome/chrome-favicon-16-16.png",
    "revision": "aeba902d4ec61a1a51076aaea4fe75e9"
  },
  {
    "url": "main/icons/chrome/chrome-installprocess-128-128.png",
    "revision": "b09a872ecbf72965ac10f9690749d5ff"
  },
  {
    "url": "main/icons/firefox/firefox-general-128-128.png",
    "revision": "b09a872ecbf72965ac10f9690749d5ff"
  },
  {
    "url": "main/icons/firefox/firefox-general-16-16.png",
    "revision": "aeba902d4ec61a1a51076aaea4fe75e9"
  },
  {
    "url": "main/icons/firefox/firefox-general-256-256.png",
    "revision": "a6edb862c47b764c2caea16f87ddb31e"
  },
  {
    "url": "main/icons/firefox/firefox-general-32-32.png",
    "revision": "cff9e4bf75944db9e30f970c4e42c435"
  },
  {
    "url": "main/icons/firefox/firefox-general-48-48.png",
    "revision": "2f67dc9eec91616ee09c03eaa420e628"
  },
  {
    "url": "main/icons/firefox/firefox-general-64-64.png",
    "revision": "7cf94055fd7e9ba52e0bb204a34ed62a"
  },
  {
    "url": "main/icons/firefox/firefox-general-90-90.png",
    "revision": "d4ed080e6b658fba23eb798aa145ec26"
  },
  {
    "url": "main/icons/firefox/firefox-marketplace-128-128.png",
    "revision": "b09a872ecbf72965ac10f9690749d5ff"
  },
  {
    "url": "main/icons/firefox/firefox-marketplace-512-512.png",
    "revision": "73c0b947844e658446da1ec72cf8b95a"
  },
  {
    "url": "main/icons/manifest.json",
    "revision": "d5174502f20bf19c8aab28135087ede8"
  },
  {
    "url": "main/js/main.js",
    "revision": "ca09792e38479a31ff97ebb19a1ed337"
  },
  {
    "url": "main/js/tags.js",
    "revision": "f647a49bed73b371c69692da1503ed38"
  },
  {
    "url": "main/js/zakroon.js",
    "revision": "60220ab3c338ecdae09eaee5a8000500"
  },
  {
    "url": "main/vendor/gsap.min.js",
    "revision": "5b20e1b9b1c3ead05cd6c0c385128526"
  },
  {
    "url": "main/vendor/hammer.min.js",
    "revision": "dd16fba4974cfe81d9075c6367474cb2"
  },
  {
    "url": "main/vendor/riot.min.js",
    "revision": "a64385e469ff924c7017cdf1507f1a7f"
  },
  {
    "url": "main/vendor/route.min.js",
    "revision": "79a7ba9487c2e65aefe2cf264bf84e5c"
  },
  {
    "url": "main/vendor/ScrollToPlugin.min.js",
    "revision": "44279c919afd6a18f2d424a870bcbcf1"
  },
  {
    "url": "main/vendor/ua-parser.min.js",
    "revision": "615c089c71c979729e2bcf60a61d7934"
  },
  {
    "url": "/",
    "revision": "eacf331f0ffc35d4b482f1d15a887d3b"
  }
].concat(self.__precacheManifest || []);
workbox.precaching.precacheAndRoute(self.__precacheManifest, {
  "directoryIndex": "index.html"
});

workbox.routing.registerNavigationRoute(workbox.precaching.getCacheKeyForURL("index.html"));
